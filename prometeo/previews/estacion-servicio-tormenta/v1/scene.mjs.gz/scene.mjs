// NOCTURNA v1 | EDITABLE SOURCE | home-built WebGL2 renderer, no external packages.
// Procedural UV-mapped and vertex-painted meshes; NOT a substitute for a licensed hero GLB.
const canvas=document.querySelector('#scene'), gl=canvas.getContext('webgl2',{alpha:false,antialias:true,powerPreference:'high-performance'});
if(!gl){document.querySelector('#error').style.display='grid';throw Error('WebGL2 unavailable')}
const article=new URLSearchParams(location.search).has('article');
const config={duration:19, loop:true, rainDrops:2200, wetness:.82, sky:[.026,.054,.071], carStart:-32, carEnd:-9.9};
const vs=`#version 300 es
precision highp float;layout(location=0) in vec3 aPos;layout(location=1) in vec3 aNorm;layout(location=2) in vec3 aColor;layout(location=3) in vec2 aUV;layout(location=4) in float aMat;layout(location=5) in float aEm;
uniform mat4 uVP;uniform vec3 uShift;out vec3 vPos,vNorm,vColor;out vec2 vUV;out float vMat,vEm;
void main(){vPos=aPos+uShift;vNorm=aNorm;vColor=aColor;vUV=aUV;vMat=aMat;vEm=aEm;gl_Position=uVP*vec4(vPos,1.);}`;
const fs=`#version 300 es
precision highp float;in vec3 vPos,vNorm,vColor;in vec2 vUV;in float vMat,vEm;
uniform sampler2D uSign;uniform vec3 uEye,uCar;uniform float uTime,uWet;out vec4 color;
float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
float puddle(vec2 p){p*=.85;float v=sin(p.x*1.31+sin(p.y*.66))*sin(p.y*1.75+cos(p.x*.73));return smoothstep(.18,.72,v+.14*sin(p.x*.6+p.y*.37));}
void main(){
vec3 N=normalize(vNorm);vec3 V=normalize(uEye-vPos);vec3 c=vColor;float lit=.22+max(0.,dot(N,normalize(vec3(-.35,.8,.36))))*.17;
vec3 p1=vec3(-2.2,5.6,-11.2),p2=vec3(2.3,5.6,-11.2),p3=vec3(-6.5,2.2,-20.),p4=uCar+vec3(0.,.7,1.5);
vec3 P[4]=vec3[4](p1,p2,p3,p4);
vec3 C[4]=vec3[4](vec3(.72,.92,.78),vec3(.72,.9,.84),vec3(1.,.56,.25),vec3(.78,.88,1.));
float k[4]=float[4](3.9,3.8,2.6,5.0);
float illumination=lit;vec3 extra=vec3(0.);
for(int i=0;i<4;i++){vec3 delta=P[i]-vPos;float d=length(delta);float fall=k[i]/(1.+d*d*.20);float diffuse=max(0.,dot(N,normalize(delta)));float spec=pow(max(0.,dot(reflect(-normalize(delta),N),V)),i==3?28.:18.);extra+=C[i]*fall*(diffuse*.52+spec*.32);illumination+=fall*diffuse*.12;}
if(vMat>.5&&vMat<1.5){ // aggregate asphalt and irregular shallow standing water
float n=hash(floor(vPos.xz*44.));float w=puddle(vPos.xz);float ripple=sin(length(fract(vPos.xz*1.9)-.5)*32.-uTime*8.)*.015;
c=vec3(.078,.106,.123)+vec3(.036)*n;c=mix(c,vec3(.079,.116,.139),w*.74*uWet);extra+=vec3(.035,.11,.13)*w;
float refl=pow(1.-max(dot(N,V),0.),2.);extra+=vec3(.05,.13,.16)*(w*.65+refl*.5);
// long stretched reflections aligned to incoming camera rays, not fake mirrored objects
for(int j=0;j<3;j++){vec2 delta=vPos.xz-P[j].xz;float streak=exp(-abs(delta.x)*(.45+.2*float(j)))*exp(-abs(delta.y)*.082);extra+=C[j]*streak*w*.41*(.6+.4*sin(delta.y*7.+n*9.+uTime*2.));}
extra*=1.+ripple;illumination=.9;
}
if(vMat>1.5&&vMat<2.5){vec4 tex=texture(uSign,vUV);c=mix(c,tex.rgb,tex.a);illumination=max(illumination,.76);}
if(vMat>2.5&&vMat<3.5){float f=pow(1.-abs(dot(N,V)),2.);c=mix(vec3(.018,.044,.055),vec3(.16,.27,.3),f*.52);extra+=vec3(.065,.12,.13);}
vec3 rgb=c*illumination+extra+c*vEm*.78;
float dist=length(vPos-uEye);float fog=1.-exp(-dist*.025);rgb=mix(rgb,vec3(.038,.075,.087),clamp(fog*.85,0.,.8));rgb=1.-exp(-rgb*1.12);
color=vec4(pow(rgb,vec3(.91)),1.);
}`;
const rainVS=`#version 300 es
precision highp float;layout(location=0) in vec4 a;uniform mat4 uVP;uniform float uTime;uniform vec3 uCar;out float vAlpha;void main(){float y=mod(a.y-uTime*(11.+a.w*7.),15.);vec3 p=vec3(a.x+y*.037,y+.15,a.z);p.y+=gl_VertexID%2==0?0.:.27;gl_Position=uVP*vec4(p,1.);float front=p.z-uCar.z;float beam=smoothstep(0.,1.5,front)*(1.-smoothstep(12.,24.,front))*(1.-smoothstep(.9,4.5,abs(p.x-uCar.x)));vAlpha=(.13+.20*a.w+.46*beam)*(1.-smoothstep(28.,60.,abs(p.z)));}`;
const rainFS=`#version 300 es
precision highp float;in float vAlpha;out vec4 frag;void main(){frag=vec4(.58,.82,.90,vAlpha);}`;
function program(v,f){const sh=(t,s)=>{let x=gl.createShader(t);gl.shaderSource(x,s);gl.compileShader(x);if(!gl.getShaderParameter(x,gl.COMPILE_STATUS))throw Error(gl.getShaderInfoLog(x));return x};let p=gl.createProgram();gl.attachShader(p,sh(gl.VERTEX_SHADER,v));gl.attachShader(p,sh(gl.FRAGMENT_SHADER,f));gl.linkProgram(p);if(!gl.getProgramParameter(p,gl.LINK_STATUS))throw Error(gl.getProgramInfoLog(p));return p}
const prog=program(vs,fs),rainProg=program(rainVS,rainFS);
function pos(a){return Math.hypot(...a)}function norm(a){let l=pos(a)||1;return a.map(x=>x/l)}function cross(a,b){return[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]}function sub(a,b){return a.map((v,i)=>v-b[i])}function dot(a,b){return a.reduce((s,v,i)=>s+v*b[i],0)}
const surfaces={world:[],pump:[],car:[],door:[],roadSign:[]};let dst=surfaces.world;
function tri(a,b,c,col=[.25,.34,.32],mat=0,em=0,uvs=[[0,0],[1,0],[1,1]]){let n=norm(cross(sub(b,a),sub(c,a)));for(let [j,v] of [a,b,c].entries())dst.push(...v,...n,...col,...uvs[j],mat,em)}
function quad(a,b,c,d,col,mat=0,em=0,uv=[[0,0],[1,0],[1,1],[0,1]]){tri(a,b,c,col,mat,em,uv.slice(0,3));tri(a,c,d,col,mat,em,[uv[0],uv[2],uv[3]])}
function box(x,y,z,w,h,d,c,mat=0,em=0){let a=x-w/2,b=x+w/2,e=y-h/2,f=y+h/2,g=z-d/2,k=z+d/2;quad([a,e,k],[b,e,k],[b,f,k],[a,f,k],c,mat,em);quad([b,e,g],[a,e,g],[a,f,g],[b,f,g],c,mat,em);quad([b,e,k],[b,e,g],[b,f,g],[b,f,k],c,mat,em);quad([a,e,g],[a,e,k],[a,f,k],[a,f,g],c,mat,em);quad([a,f,k],[b,f,k],[b,f,g],[a,f,g],c,mat,em);quad([a,e,g],[b,e,g],[b,e,k],[a,e,k],c,mat,em)}
function extrude(profile,z0,z1,c,mat=0,em=0){const n=profile.length;for(let i=0;i<n;i++){const a=profile[i],b=profile[(i+1)%n];quad([a[0],a[1],z0],[b[0],b[1],z0],[b[0],b[1],z1],[a[0],a[1],z1],c,mat,em)}for(let i=1;i<n-1;i++){tri([profile[0][0],profile[0][1],z0],[profile[i+1][0],profile[i+1][1],z0],[profile[i][0],profile[i][1],z0],c,mat,em);tri([profile[0][0],profile[0][1],z1],[profile[i][0],profile[i][1],z1],[profile[i+1][0],profile[i+1][1],z1],c,mat,em)}}
function ribbon(points,width,c,mat=0,em=0){for(let i=0;i<points.length-1;i++){const a=points[i],b=points[i+1];quad([a[0]-width,a[1],a[2]],[a[0]+width,a[1],a[2]],[b[0]+width,b[1],b[2]],[b[0]-width,b[1],b[2]],c,mat,em)}}
function cylinder(cx,cy,cz,r,h,col,axis='y',segments=12,em=0){const at=(ang,s)=>{const a=Math.cos(ang)*r,b=Math.sin(ang)*r;return axis==='y'?[cx+a,cy+s*h/2,cz+b]:[cx+s*h/2,cy+a,cz+b]};for(let i=0;i<segments;i++){const a=i*Math.PI*2/segments,b=(i+1)*Math.PI*2/segments;quad(at(a,-1),at(b,-1),at(b,1),at(a,1),col,0,em);tri(axis==='y'?[cx,cy+h/2,cz]:[cx+h/2,cy,cz],at(a,1),at(b,1),col,0,em)}}
// Asphalt: tiny material variations in fragment stage, with matching actual 3D plane.
quad([-80,-.08,30],[80,-.08,30],[80,-.08,-90],[-80,-.08,-90],[.065,.075,.08],1);
// Lane markings
for(let z=-58;z<22;z+=8)box(4.4,-.055,z,.12,.009,3.3,[.28,.3,.24]);
// One unique custom service pump, editable profile + layered UV signage.
dst=surfaces.pump;
const pumpProfile=[[-.62,.1],[.62,.1],[.68,.24],[.68,2.65],[.58,2.83],[-.58,2.83],[-.68,2.65],[-.68,.24]];
function pumpAt(x,z){const pro=pumpProfile.map(([a,b])=>[a+x,b]);extrude(pro,z-.47,z+.47,[.39,.54,.48]);extrude(pumpProfile.map(([a,b])=>[a*.94+x,b*.98+.04]),z+.476,z+.51,[.72,.78,.66]);
box(x,2.62,z+.52,1.08,.26,.035,[.12,.26,.23]);
// canvas sign: separate UV regions with original graphics
quad([x-.52,2.48,z+.535],[x+.52,2.48,z+.535],[x+.52,2.71,z+.535],[x-.52,2.71,z+.535],[1,1,1],2,1,[[.02,.51],[.5,.51],[.5,.72],[.02,.72]]);
box(x,1.84,z+.54,1.08,.88,.045,[.08,.14,.17]);
quad([x-.48,1.59,z+.57],[x+.48,1.59,z+.57],[x+.48,2.22,z+.57],[x-.48,2.22,z+.57],[1,1,1],2,.27,[[.02,.02],[.5,.02],[.5,.48],[.02,.48]]);
box(x,1.05,z+.56,.94,.24,.035,[.075,.18,.18]);
for(let i=0;i<3;i++)box(x-.28+i*.28,1.05,z+.59,.15,.11,.015,[.60,.67,.56]);
box(x+.75,1.68,z+.18,.19,.69,.4,[.08,.13,.15]);
// hanging fuel hose as a tapered strip tube with continuous curved identity
let hose=[];for(let i=0;i<=20;i++){let t=i/20;hose.push([x+.76+.28*Math.sin(Math.PI*t),1.82-.95*t-.17*Math.sin(Math.PI*t),z+.56+.24*Math.sin(Math.PI*t)])}ribbon(hose,.05,[.048,.055,.058]);
box(x+.82,1.12,z+.46,.13,.31,.08,[.66,.72,.67]);
box(x, .12,z,1.4,.18,1.13,[.12,.16,.16]);}
pumpAt(-2.3,-11);
if(!article){
 // Structure: station canopy with custom graphic band and genuine pools of light
 dst=surfaces.world;
 for(let x of [-6.8,3.3])for(let z of [-8.6,-14]){box(x,2.75,z,.3,5.5,.34,[.21,.32,.31]);box(x,5.46,z,.59,.20,.6,[.58,.68,.6]);}
 box(-1.8,5.6,-11.5,12.2,.45,8,[.22,.38,.37]);box(-1.8,5.84,-11.5,12.4,.18,8.2,[.36,.45,.43]);box(-1.8,5.32,-7.4,12.4,.68,.19,[.14,.3,.29]);
 // Canopy identity original, physically attached to facade
 quad([-7.5,5.08,-7.27],[3.95,5.08,-7.27],[3.95,5.57,-7.27],[-7.5,5.57,-7.27],[1,1,1],2,.5,[[.02,.75],[.98,.75],[.98,.99],[.02,.99]]);
 for(let x of [-4.4,0.8])for(let z of [-10,-13])box(x,5.33,z,1.4,.045,1.0,[.66,.96,.81],0,1.1);
 // building behind pumps, genuine door opening with amber behind it
 box(-5.5,2.45,-21.8,11.7,4.9,2.9,[.20,.31,.31]);box(-5.5,4.81,-20.21,11.8,.16,3.05,[.38,.42,.38]);
 box(-6.3,1.4,-20.26,1.58,2.8,.08,[.06,.15,.16]);
 box(-6.3,1.47,-20.21,1.26,2.53,.05,[.8,.46,.22],0,.8);
 box(-6.3,1.48,-20.155,.97,2.33,.05,[.83,.56,.29],0,2.1);
 dst=surfaces.door;box(-6.3,1.43,-20.06,1.23,2.62,.11,[.09,.20,.20]);box(-5.87,1.39,-19.985,.07,.20,.035,[.73,.67,.49]);dst=surfaces.world;
 box(-8.8,2.3,-20.21,2.35,1.4,.08,[.045,.085,.10],3);
 box(-8.8,2.98,-20.13,2.5,.11,.06,[.28,.47,.39]);
 box(-3.2,2.3,-20.21,2.2,1.4,.08,[.045,.085,.10],3);
 for(let z of [-21.7,-23.5])box(-11.55,4,z,.09,.4,.4,[.86,.43,.24],0,1);
 // isolated roadside sign on pole, not a labeled cuboid
 box(7.3,2.5,-23.7,.16,5,.21,[.24,.31,.32]);dst=surfaces.roadSign;box(7.3,5.8,-23.7,2.45,1.6,.3,[.08,.26,.25]);
 quad([6.17,5.14,-23.5],[8.43,5.14,-23.5],[8.43,6.44,-23.5],[6.17,6.44,-23.5],[1,1,1],2,.6,[[.53,.04],[.99,.04],[.99,.48],[.53,.48]]);dst=surfaces.world;
 // barrels, road edge and vegetation in background
 for(let [x,z] of [[-11,-14],[-12,-11],[11,-21],[12,-25]]){cylinder(x,.35,z,.42,.69,[.14,.25,.24]);box(x,.62,z,.88,.06,.88,[.3,.38,.31]);}
 // actual sculpted retro sedan body, four-wheel layout, not a named box
 dst=surfaces.car;
 // hood/trunk/main hull with bevelled wheel arch beltline and roof facets
 let lower=[[-1.05,.55,-1.83],[1.05,.55,-1.83],[1.13,.62,-1.64],[1.13,.6,1.47],[.92,.57,1.93],[-.92,.57,1.93],[-1.13,.6,1.47],[-1.13,.62,-1.64]];
 let upper=lower.map(([x,y,z])=>[x*.95,1.18,z]);
 for(let i=0;i<lower.length;i++){let j=(i+1)%lower.length;quad(lower[i],lower[j],upper[j],upper[i],[.27,.49,.44]);}
 for(let i=1;i<upper.length-1;i++)tri(upper[0],upper[i+1],upper[i],[.27,.49,.44]);
 // styled black beltline + dashboard nose
 box(0,.87,-1.88,1.91,.24,.12,[.08,.15,.15]);box(0,.74,1.92,1.87,.17,.12,[.09,.13,.14]);
 box(0,1.18,-1.64,2.04,.055,.19,[.69,.7,.57]);
 // Cabin and windows are actual trapezoidal mesh surfaces, no cubes
 const base=[[-.85,1.15,-.65],[.85,1.15,-.65],[.88,1.15,1.18],[-.88,1.15,1.18]];
 const roof=[[-.72,2.0,-.28],[.72,2.0,-.28],[.73,1.99,.67],[-.73,1.99,.67]];
 quad(base[0],base[1],roof[1],roof[0],[.025,.074,.078],3);
 quad(base[2],base[3],roof[3],roof[2],[.036,.08,.09],3);
 quad(base[1],base[2],roof[2],roof[1],[.03,.081,.09],3);
 quad(base[3],base[0],roof[0],roof[3],[.03,.081,.09],3);
 quad(roof[0],roof[1],roof[2],roof[3],[.25,.44,.4]);
 // chrome trim tracing continuous contours
 ribbon([[ -.84,1.17,-.65],[-.71,2.02,-.29]],.028,[.58,.66,.6]);
 ribbon([[ .84,1.17,-.65],[.71,2.02,-.29]],.028,[.58,.66,.6]);
 ribbon([[ -.85,1.15,1.18],[-.72,2.0,.67]],.027,[.58,.66,.6]);
 ribbon([[ .85,1.15,1.18],[.72,2.0,.67]],.027,[.58,.66,.6]);
 for(let x of [-1.12,1.12]){for(let z of [-1.05,1.15]){cylinder(x,.46,z,.45,.20,[.04,.07,.073],'x',14);cylinder(x*1.10,.46,z,.21,.035,[.51,.57,.5],'x',14);cylinder(x*1.13,.46,z,.11,.03,[.12,.17,.17],'x',9);}}
 // front rear bumpers; headlights point forward (-z)
 box(0,.5,-1.99,2.16,.14,.16,[.58,.63,.57]);
 for(let x of [-.78,.78]){box(x, .99,-1.97,.38,.25,.07,[.80,.88,.76],0,2.1);box(x,.8,1.97,.36,.15,.07,[.71,.19,.12],0,.7)}
 box(0,.78,-1.99,.66,.21,.045,[.035,.07,.075]);
 for(let i=0;i<6;i++)box(-.26+i*.10,.78,-2.018,.028,.18,.01,[.50,.57,.52]);
}
// UV canvas atlas: all art produced in code, independently editable.
const atlas=document.createElement('canvas');atlas.width=1024;atlas.height=512;const g=atlas.getContext('2d');
g.fillStyle='#102528';g.fillRect(0,0,1024,512);g.fillStyle='#d4e7cf';g.fillRect(0,0,520,250);g.fillStyle='#244445';g.fillRect(13,13,494,224);g.fillStyle='#cbd7b8';g.font='700 69px monospace';g.fillText('98.7',88,117);g.font='700 35px monospace';g.fillText('REGULAR',112,186);g.fillStyle='#142b2d';g.fillRect(0,250,520,115);g.fillStyle='#d6e4c5';g.font='900 60px sans-serif';g.fillText('Nº 04',70,323);
g.fillStyle='#d9cba5';g.fillRect(535,0,489,246);g.fillStyle='#193d3d';g.fillRect(548,14,461,218);g.fillStyle='#e0d9c2';g.font='bold 105px sans-serif';g.fillText('24',645,142);g.font='bold 26px sans-serif';g.fillText('KM',724,193);
g.fillStyle='#17383a';g.fillRect(0,370,1024,142);g.fillStyle='#d8e4cd';g.font='900 97px sans-serif';g.fillText('N O C T U R N A',49,477);g.fillStyle='#bb7552';g.fillRect(0,370,1024,8);
const tex=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,tex);gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,true);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,atlas);gl.generateMipmap(gl.TEXTURE_2D);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR_MIPMAP_LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);
function createMesh(data){const b=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,b);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(data),gl.STATIC_DRAW);return{b,count:data.length/13}}
// Vehicle authored with nose at local -Z, then turned to face the entrance (+Z).
for(let i=0;i<surfaces.car.length;i+=13){surfaces.car[i+2]*=-1;surfaces.car[i+5]*=-1;}
const meshes=Object.fromEntries(Object.entries(surfaces).map(([name,data])=>[name,createMesh(data)]));
const rain=[];let rand=16431;function rnd(){rand=(Math.imul(1664525,rand)+1013904223)>>>0;return rand/4294967296}
for(let i=0;i<config.rainDrops;i++){let x=(rnd()-.5)*48-2,z=-rnd()*45+11,y=rnd()*15,w=rnd();rain.push(x,y,z,w,x,y,z,w)}
const rainBuffer=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,rainBuffer);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(rain),gl.STATIC_DRAW);
const uniform=(p,s)=>gl.getUniformLocation(p,s);
function setup(mesh){gl.bindBuffer(gl.ARRAY_BUFFER,mesh.b);const n=13*4;for(let [i,size,start] of [[0,3,0],[1,3,3],[2,3,6],[3,2,9],[4,1,11],[5,1,12]]){gl.enableVertexAttribArray(i);gl.vertexAttribPointer(i,size,gl.FLOAT,false,n,start*4)}}
function perspective(fov,aspect,near,far){let f=1/Math.tan(fov/2),a=1/(near-far);return[f/aspect,0,0,0,0,f,0,0,0,0,(far+near)*a,-1,0,0,2*far*near*a,0]}
function view(eye,target){let z=norm(sub(eye,target)),x=norm(cross([0,1,0],z)),y=cross(z,x);return[x[0],y[0],z[0],0,x[1],y[1],z[1],0,x[2],y[2],z[2],0,-dot(x,eye),-dot(y,eye),-dot(z,eye),1]}
function mul(a,b){let o=new Array(16).fill(0);for(let r=0;r<4;r++)for(let c=0;c<4;c++)for(let k=0;k<4;k++)o[c*4+r]+=a[k*4+r]*b[c*4+k];return o}
function lerp(a,b,t){return a+(b-a)*t}function ease(t){return t*t*(3-2*t)}
let running=true,time=0,last=performance.now();document.querySelector('#play').addEventListener('click',()=>{running=!running;document.querySelector('#play').textContent=running?'Ⅱ':'▶'});
canvas.addEventListener('click',()=>{if(time>config.duration-1){time=0;running=true;document.querySelector('#play').textContent='Ⅱ'}});
const debug={draws:0,faces:(meshes.world.count+meshes.pump.count+meshes.car.count)/3,rain:config.rainDrops,article,frames:0,errors:[]};window.__SCENE_QA__=debug;
function render(now){let dt=Math.min(.1,(now-last)/1000);last=now;if(running)time+=dt;if(time>=config.duration)time=config.loop?0:config.duration;const t=time;
const w=Math.max(1,Math.round(canvas.clientWidth*Math.min(devicePixelRatio||1,1.7))),h=Math.max(1,Math.round(canvas.clientHeight*Math.min(devicePixelRatio||1,1.7)));
if(canvas.width!==w||canvas.height!==h){canvas.width=w;canvas.height=h;gl.viewport(0,0,w,h)}
let phase=ease(Math.min(t/15,1));let eye=[lerp(5.4,-.9,phase),lerp(.55,1.7,phase),lerp(7.6,-1.8,phase)];let look=[lerp(-1.1,-1.0,phase),lerp(.85,1.7,phase),lerp(-12.8,-11.7,phase)];
if(article){eye=[.4,1.,-2.5];look=[-2.3,1.5,-11.]}
const aspect=w/h;if(aspect<.85){eye[2]+=8.0;eye[0]+=1.3;}
const vp=mul(perspective((aspect<.85?80:58)*Math.PI/180,aspect,.08,110),view(eye,look));const carZ=lerp(config.carStart,config.carEnd,ease(Math.min(t/12,1)));const car=[2.8,.05,carZ];
gl.clearColor(...config.sky,1);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);gl.enable(gl.DEPTH_TEST);gl.disable(gl.CULL_FACE);
gl.useProgram(prog);gl.uniformMatrix4fv(uniform(prog,'uVP'),false,new Float32Array(vp));gl.uniform3fv(uniform(prog,'uEye'),new Float32Array(eye));gl.uniform3fv(uniform(prog,'uCar'),new Float32Array(car));gl.uniform1f(uniform(prog,'uTime'),t);gl.uniform1f(uniform(prog,'uWet'),config.wetness);gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,tex);gl.uniform1i(uniform(prog,'uSign'),0);
for(let name of ['world','pump','car','door','roadSign']){if(article&&name==='car')continue;let m=meshes[name];if(!m.count)continue;setup(m);let doorOpen=ease(Math.min(1,Math.max(0,(t-12.6)/1.35)));let shift=name==='car'?car:name==='door'?[doorOpen*1.2,0,0]:name==='roadSign'?[Math.sin(t*13)*.035,Math.sin(t*18)*.015,0]:[0,0,0];gl.uniform3fv(uniform(prog,'uShift'),new Float32Array(shift));gl.drawArrays(gl.TRIANGLES,0,m.count);debug.draws++}
gl.enable(gl.BLEND);gl.blendFunc(gl.SRC_ALPHA,gl.ONE);gl.depthMask(false);gl.useProgram(rainProg);gl.uniformMatrix4fv(uniform(rainProg,'uVP'),false,new Float32Array(vp));gl.uniform1f(uniform(rainProg,'uTime'),t);gl.uniform3fv(uniform(rainProg,'uCar'),new Float32Array(car));gl.bindBuffer(gl.ARRAY_BUFFER,rainBuffer);gl.enableVertexAttribArray(0);gl.vertexAttribPointer(0,4,gl.FLOAT,false,16,0);gl.drawArrays(gl.LINES,0,config.rainDrops*2);gl.depthMask(true);gl.disable(gl.BLEND);debug.frames++;requestAnimationFrame(render)}
requestAnimationFrame(render);
